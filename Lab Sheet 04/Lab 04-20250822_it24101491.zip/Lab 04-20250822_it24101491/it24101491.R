
#q1(Import the dataset a data frame)

setwd("C:\\Users\\it24101491\\Downloads\\Lab 04-20250822")
branch_data<-read.table("Exercise.txt",header=TRUE,sep = ",")
fix(branch_data)
attach(branch_data)


#q2(. Identify the variable type)

class(branch_data$Branch)
class(branch_data$Sales_X1)
class(branch_data$Advertising_X2)
class(branch_data$Years_X3)


#q3(Obtain boxplot for sales and interpret the shape of the sales distribution)

boxplot(branch_data$Sales_X1, Main="Sales",outline=TRUE, outpch=8, horizontal=TRUE,xlab="Sales")
hist(branch_data$Sales_X1, Main="Sales",outline=TRUE,outpch=8, horizontal=TRUE)

#Q4(. Calculate the five number summary)

summary(Advertising_X2)
IQR(Advertising_X2)

#Q5(R function to find the outliers in a numeric vector)

get.outlier <-function(x){
  q1<-quantile(x)[2]
  q3<-quantile(x)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers =", paste(sort(x[x<lb | x>ub]),collapse=",")))}
get.outlier(Years_X3)

